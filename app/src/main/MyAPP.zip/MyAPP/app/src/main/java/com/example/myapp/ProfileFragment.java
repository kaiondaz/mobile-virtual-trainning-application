package com.example.myapp;


import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment {
    //Firebase
    FirebaseAuth firebaseAuth;
    FirebaseUser user;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference,UsersRef ;
    String currentUserID;


    //Views from xml
    TextView nameTv;
    TextView emailTv;

    ImageView AvatarIv;
    String Name;
    View profileView;
    Button Mydetails;
    private RecyclerView myProfileInfo;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_profile, container, false);

        nameTv= view.findViewById(R.id.NameTv);
        emailTv= view.findViewById(R.id.EmailTv);
        Mydetails= view.findViewById(R.id.myDetails);
        AvatarIv=view.findViewById(R.id.AddressTv);




        //init firebase
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        currentUserID = user.getUid();
        firebaseDatabase = FirebaseDatabase.getInstance();
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();

        databaseReference = firebaseDatabase.getReference("Clients").child(currentUserID);
        //UsersRef=firebaseDatabase.getReference("Users");

        //Method to change user details
        Mydetails.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View view) {

                Intent myIntent = new Intent(getContext(), user_details.class);
                // myIntent.putExtra("key", value); //Optional parameters
                ProfileFragment.this.startActivity(myIntent);

            }});

        Query query = databaseReference.orderByChild("email").equalTo(user.getEmail());
        databaseReference.addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        //check until required data get
                                                        // This method is called once with the initial value and again
                                                        // whenever data at this location is updated.
                                                        Client2 client = dataSnapshot.getValue(Client2.class);
                                                        Toast.makeText(getContext(), "SUCCESS"+client.getName(), Toast.LENGTH_SHORT).show();
                                                        nameTv.setText(client.getName());
                                                        emailTv.setText(client.getEmail());
                                                        String link=client.getImageAddress();


                                                        try{
                                                            Picasso.get().load(link).fit().into(AvatarIv);
                                                            Toast.makeText(getContext(), link, Toast.LENGTH_LONG).show();

                                                           // Picasso.Builder builder = new Picasso.Builder(getContext());
                                                            //builder.listener(new Picasso.Listener() {


                                                               // @Override
                                                                //public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                                                                  //  exception.printStackTrace();
                                                                //};

                                                        //});
                                                            }

                                                        catch(Exception e) {
                                                            //if there is any execption while geting the image  then set default
                                                            Picasso.get().load(R.mipmap.ic_add_image).into(AvatarIv);
                                                        }

                                                        // Log.d(TAG, "Value is: " + value);
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }


                                                    // try{
                                                    //       Picasso.get().load(Image).into(avatarIv);
                                                    // }

                                                    //catch(Exception e) {
                                                    //if there is any execption while geting the image  then set default
                                                    //  Picasso.get().load(R.mipmap.ic_add_image).into(avatarIv);
                                                    //}}}

                                                    //  @Override
                                                    //public void onCancelled(@NonNull DatabaseError databaseError) {
                                                    //  Toast.makeText(LOOOOOOOOOOL.this,"NOOOOOT working",Toast.LENGTH_LONG).show();


                                                    //}


                                                }






        );

        return view;
    }



}
