package com.example.myapp;


public class Client2 {

    private String Name;
    private String address;
    private String email;
    private String createPassword;
    private String id;


    private String imageAddress;

    public Client2(){

    }

    public Client2(String name,String Address,String Email,String CreatePassword,String ID){
        Name =name;
        address=Address;
        email=Email;
        createPassword=CreatePassword;
        id=ID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCreatePassword() {
        return createPassword;
    }

    public void setCreatePassword(String createPassword) {
        this.createPassword = createPassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return Name;
    }

    public void setID (String ID) {this.id=ID;}

    public String getID (String ID) {return id;}

    public void setName(String name) {
        this.Name = name;
    }

    public String getImageAddress() { return imageAddress; }

    public void setImageAddress(String imageAddress) {this.imageAddress = imageAddress;}
}
