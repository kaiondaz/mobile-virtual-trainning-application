package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Register_User_Type extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register__user__type);
    }



    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.Client_Button:
                Intent myIntent2 = new Intent(Register_User_Type.this, registration.class);
                // myIntent.putExtra("key", value); //Optional parameters
                Register_User_Type.this.startActivity(myIntent2);

                break;
            case R.id.Trainer_Button:
                Intent myIntent = new Intent(Register_User_Type.this, Register_User_Type.class);
                // myIntent.putExtra("key", value); //Optional parameters
                Register_User_Type.this.startActivity(myIntent);
                break;

            case R.id.Nutricionist_Button:
                Intent myIntent3 = new Intent(Register_User_Type.this, Register_User_Type.class);
                // myIntent.putExtra("key", value); //Optional parameters
                Register_User_Type.this.startActivity(myIntent3);

        }



    }













}
